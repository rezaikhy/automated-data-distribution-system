	# Automated Data Distribution System

## Overview

Automated Data Distribution System is a workflow automation solution developed using Google Apps Script and Google Sheets.

The system automatically distributes campaign data from a centralized source spreadsheet to multiple target spreadsheets based on predefined distribution plans, while maintaining logs, tracking distribution positions, and handling scheduling rules.

This automation reduces repetitive manual work, minimizes human error, and improves operational efficiency.

---

## Problem Statement

Before automation:

- Data distribution was performed manually.
- Repetitive copy-paste activities consumed significant time.
- Distribution tracking was difficult to monitor.
- Human errors frequently occurred during campaign execution.
- No centralized distribution log was available.

---

## Solution

This system automates the entire distribution process by:

- Reading distribution plans from a master sheet.
- Retrieving data from source spreadsheets.
- Distributing data automatically to target spreadsheets.
- Tracking distribution progress.
- Recording distribution history into logs.
- Preventing distribution on Sundays and national holidays.
- Automatically resetting distribution positions when the source data limit is reached.

---

## Key Features

### Automated Data Distribution
Automatically transfers data from source spreadsheets to destination spreadsheets.

### Distribution Tracking
Tracks the current distribution position to prevent duplicate data allocation.

### Activity Logging
Stores all distribution activities and execution results.

### Holiday Validation
Automatically skips execution on Sundays and national holidays.

### Auto Reset Mechanism
Resets distribution position when the source dataset has been fully processed.

### Campaign Management
Supports multiple campaign distribution plans from a single control sheet.

---

## Technologies Used

- Google Apps Script
- Google Sheets
- JavaScript
- Spreadsheet Automation

---

## Workflow

1. Read active campaign plans.
2. Validate campaign status and end date.
3. Check holiday and Sunday restrictions.
4. Retrieve data from source spreadsheet.
5. Distribute data to target spreadsheet.
6. Update distribution position.
7. Record execution logs.
8. Handle errors automatically.

---

## Business Impact

- Reduced manual distribution workload.
- Improved operational efficiency.
- Minimized data distribution errors.
- Increased campaign execution consistency.
- Simplified monitoring and reporting processes.

---

## Project Category

Operations Automation | Workflow Automation | Data Distribution System

---

## Author

Developed by Reza Ikhy

Portfolio Project 2026